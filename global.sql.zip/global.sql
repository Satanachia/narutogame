-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2021 at 10:40 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `global`
--

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

DROP TABLE IF EXISTS `calendar`;
CREATE TABLE IF NOT EXISTS `calendar` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_game` int(11) NOT NULL,
  `title` varchar(40) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date_start` timestamp NULL DEFAULT NULL,
  `date_end` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_game` (`id_game`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `calendar`
--

INSERT INTO `calendar` (`id`, `id_game`, `title`, `description`, `date_start`, `date_end`) VALUES
(1, 2, 'Round Oficial 1', NULL, '2010-12-03 20:00:00', '2011-03-03 20:00:00'),
(2, 1, 'Festa de Créditos para o Natal', 'Neste Natal nós da STAFF queremos que todos os jogadores possuam muitos créditos e para isso estaremos criando uma promoção EXCLUSIVA para esse fim de ano ( Natal e Ano Novo ).\n\nTodos os jogadores que comprarem créditos a partir de amanhã ( 14/12/2010 ) até 03/01/2011 estarão ganhando:\n\nVip Genin\n\nAos que comprarem esse plano ganharão créditos em dobro ( 20 ) créditos + 5 créditos.\nForum das Vilas\nTotal de 25 créditos por 10 reais.\n\nVip Chunin\n\nAos que comprarem esse plano ganharão créditos em dobro ( 44 ) créditos + 11 créditos.\nTotal de 55 créditos por 20 reais.\n\nVip Jounin\n\nAos que comprarem esse plano ganharão créditos em dobro ( 70 ) créditos + 18 créditos.\nTotal de 88 créditos por 30 reais.\n\nVip ANBU\n\nAos que comprarem esse plano ganharão créditos em dobro ( 98 ) créditos + 25 créditos.\nTotal de 123 créditos por 40 reais.\n\nVip Sanin\n\nAos que comprarem esse plano ganharão créditos em dobro ( 128 ) créditos + 32 créditos.\nTotal de 160 créditos por 50 reais.', '2010-12-14 00:00:00', '2011-01-03 00:00:00'),
(4, 1, 'Evento: O Poder dos sannins', '', '2010-12-15 00:00:00', '2010-12-15 23:59:59'),
(5, 1, 'Evento: Os Lendários Sannins', NULL, '2010-12-18 00:00:00', '2010-12-18 23:59:59'),
(6, 1, 'Evento: Gerações de Heróis', 'As gerações passam, aprendizes se tornam mestres, mestres se tornam lendas. Agora, eles estão juntos para mostrar este poder. Enfrente-os e mostre que cada geração que passa, os ninjas são mais fortes.', '2010-12-22 00:00:00', '2010-12-22 23:59:59'),
(7, 1, 'Evento: Captura das Bijuu\'s', NULL, '2010-12-25 00:00:00', '2010-12-25 23:59:59'),
(8, 1, 'Evento: Destruir os Peins', NULL, '2010-12-29 00:00:00', '2010-12-29 23:59:59'),
(9, 1, 'Evento: Ranking Veterano e Intemediário ', 'Esse evento acontece todo meio do round e vai dividir todos os ninjas em dois ranks ( Veterano e Intemediário ).\n\nO Rank Veterano será constituido por ninjas acima do level 29 que lutam diretamente pelas primeiras colocações do jogo.\n\nO Rank Intemediário será constituido por ninjas até o level 29 que ganharão prêmios inferiores aos do Rank de Veteranos e não serão adicionados no Hall da Fama.\n\nPs.: Os prêmios do Rank Intermediário ainda será anunciado no jogo.', '2010-12-15 00:00:00', '2011-02-28 00:00:00'),
(10, 2, 'Festa de Créditos para o Natal', 'Neste Natal nós da STAFF queremos que todos os jogadores possuam muitos créditos e para isso estaremos criando uma promoção EXCLUSIVA para esse fim de ano ( Natal e Ano Novo ).\n\nTodos os jogadores que comprarem créditos a partir de amanhã ( 14/12/2010 ) até 03/01/2011 estarão ganhando:\n\nVip Genin\n\nAos que comprarem esse plano ganharão créditos em dobro ( 20 ) créditos + 5 créditos.\nForum das Vilas\nTotal de 25 créditos por 10 reais.\n\nVip Chunin\n\nAos que comprarem esse plano ganharão créditos em dobro ( 44 ) créditos + 11 créditos.\nTotal de 55 créditos por 20 reais.\n\nVip Jounin\n\nAos que comprarem esse plano ganharão créditos em dobro ( 70 ) créditos + 18 créditos.\nTotal de 88 créditos por 30 reais.\n\nVip ANBU\n\nAos que comprarem esse plano ganharão créditos em dobro ( 98 ) créditos + 25 créditos.\nTotal de 123 créditos por 40 reais.\n\nVip Sanin\n\nAos que comprarem esse plano ganharão créditos em dobro ( 128 ) créditos + 32 créditos.\nTotal de 160 créditos por 50 reais.', '2010-12-14 00:00:00', '2011-01-03 00:00:00'),
(12, 2, 'Experiência em Dobro!', 'Todos os jogadores do Bleach Game serãop beneficiados com Experiência em dobro nos combates!', '2011-01-10 00:00:00', '2011-01-12 23:59:00'),
(13, 1, 'Novo Módulo: Missões com Drop', 'As missões interativas de DROP são uma nova funcionalidade que será implementada no Naruto Game, nela você precisa matar o NPC e ter a sorte dele dropar itens que são requerimentos da missão e somente com todos esses requerimentos você completará a missão.\n\nEssas missões terão como funcionalidade especial o drop de itens raros dos npcs ( Que dropara armas, jutsus e ramens ), onde as armas e jutsus serão totalmente exclusivos ( novos ).\n\n', '2011-01-03 00:00:00', '2011-01-03 23:59:59'),
(14, 1, 'Novo Módulo: Bingo Book ANBU', 'Cada ninja ANBU terá um Bingo Book particular que a cada semana mostrará inimigos aleatórios do jogo para caça-los e para cada player caçado e morto o player ganhará uma recompensa. ( Exp e Ryous )\n\nEsse módulo só estara disponivel para ninjas ANBU e Sannin.\n', '2011-01-10 00:00:00', '2011-01-10 23:59:59'),
(15, 1, 'Promoção: Exp em Dobro', 'Promoção onde todos os players em combates PVP ganham o dobro de Experiência ao vencer seus inimigos.', '2011-01-17 00:00:00', '2011-01-19 00:00:00'),
(16, 1, 'Eliminar a Akatsuki', NULL, '2011-01-01 00:00:00', '2011-01-01 23:59:59'),
(17, 1, 'Portadores do Selo Amaldiçoado', NULL, '2011-01-05 00:00:00', '2011-01-05 23:59:59'),
(18, 1, 'O poder dos Kages', NULL, '2011-01-08 00:00:00', '2011-01-08 23:59:59'),
(19, 1, 'O poder dos Sennin', NULL, '2011-01-12 00:00:00', '2011-01-12 23:59:59'),
(20, 1, 'Os Lendários Sannins', NULL, '2011-01-15 00:00:00', '2011-01-15 23:59:59'),
(21, 1, 'Gerações de Heróis', 'As gerações passam, aprendizes se tornam mestres, mestres se tornam lendas. Agora, eles estão juntos para mostrar este poder. Enfrente-os e mostre que cada geração que passa, os ninjas são mais fortes.', '2011-01-19 00:00:00', '2011-01-19 23:59:59'),
(22, 1, 'Captura das Bijuu\'s', 'As Bijuu\'s estÃ£o fora de controle, colocando todo o Mundo em risco, Ã© nosso dever proteger nÃ£o sÃ³ nossa Vila, bem como manter a paz em todo o Mundo Shinobi! Ã‰ preciso deter todas as Bijuu\'s!', '2011-01-22 00:00:00', '2011-01-22 23:59:59'),
(23, 1, 'Destruir os Peins', 'Pein quer que o mundo conheÃ§a a Dor, mas mal sabe ele que todos jÃ¡ conhecem de formas diferentes mas jÃ¡ conhecem. Elimine todos os Peins e encerre o fanatismo de Nagato, sobre dor ao mundo.', '2011-01-26 00:00:00', '2011-01-26 23:59:59'),
(24, 1, 'Eliminar a Akatsuki', 'O intuito desta organizaÃ§Ã£o Ã© tomar controle do Mundo Ninja. O fanatismo de Pein, suposto lÃ­der, Ã© fazer o mundo conhecer a \"dor\". De onde vem seu pseudonimo \"Pein\", referente a \"pain\", dor em inglÃªs. Possui poderosos integrantes, cada qual com habilidades Ãºnicas e especiais.', '2011-01-29 00:00:00', '2011-01-29 23:59:59'),
(25, 1, 'Aniversário do Naruto Game ( 2 anos )', 'Oficialmente 2 anos no ar!\r\n\r\nCom muito trabalho e conquistas nosso jogo completa hoje 2 anos de vida.\r\n\r\nNessa data acontecerá diversas promoções no jogo!', '2011-01-28 00:00:00', '2011-01-28 23:59:59'),
(26, 1, 'Promoção de Créditos em Dobro Especial ', 'Créditos em Dobro Especial ( Hoje até 14/02/2011)\r\n\r\nVip Genin\r\n\r\nAos que comprarem esse plano ganharão créditos em dobro ( 20 ) créditos + 5 créditos.\r\nTotal de 25 créditos por 10 reais.\r\n\r\nVip Chunin\r\n\r\nAos que comprarem esse plano ganharão créditos em dobro ( 44 ) créditos + 11 créditos.\r\nTotal de 55 créditos por 20 reais.\r\n\r\nVip Jounin\r\n\r\nAos que comprarem esse plano ganharão créditos em dobro ( 70 ) créditos + 18 créditos.\r\nTotal de 88 créditos por 30 reais.\r\n\r\nVip ANBU\r\n\r\nAos que comprarem esse plano ganharão créditos em dobro ( 98 ) créditos + 25 crÃ©ditos.\r\nTotal de 123 créditos por 40 reais.\r\n\r\nVip Sanin\r\n\r\nAos que comprarem esse plano ganharão créditos em dobro ( 128 ) créditos + 32 créditos.\r\nTotal de 160 créditos por 50 reais.\r\n', '2011-01-21 00:00:00', '2011-02-14 00:00:00'),
(27, 2, 'ManutenÃ§Ã£o de Final de Round', 'Backup dos dados dos jogadores;\r\n\r\nDefinição final dos Rankings e dos Vencedores;\r\n\r\nNão será possível realizar login no site, apensas as seções comuns e a opção de criar Cadastro estarão disponíveis.', '2011-03-04 00:00:00', '2011-03-07 16:00:00'),
(28, 1, 'Pré Oficial do Round 4', 'Round que vai ser para testar as mudanças do Round 4 para minimizar todos os bugs nas diversas mudanças propostas para o mesmo.\n\nDatas podem ser alteradas conforme novos planejamentos.', '2011-02-28 00:00:00', '2011-03-25 12:00:00'),
(29, 1, 'Round 4', 'Sejam bem vindos jogadores,\r\n\r\nEstamos iniciando mais um Round do NarutoGame, e antes de mais nada quero agradecer a todos pela ajuda e cooperaÃ§Ã£o durante o Round prÃ©-oficial.\r\n\r\nTodos os personagens tiveram os seus nomes e classes alteradas para se adequarem ao novo sistema de nomes do jogo, para que nÃ£o haja problemas todos os jogadores que tenham personagens com nomes seguidos de nÃºmeros receberÃ£o 4 crÃ©ditos para alterar o nome e a classe de um personagem.\r\n\r\nO Round 4 vem com diversas novidades e mudanÃ§as entre elas estÃ£o:\r\n\r\nEscolha da classe;\r\nNovos atributos e formulas;\r\nNovos personagens;\r\nNovas conquistas;\r\nEstudo Ninja;\r\nMudanÃ§as nos clÃ£s, invocaÃ§Ãµes, selos, etc.;\r\nBatalhas de equipe contra NPC (4x1 ou 4x4);\r\nRanking de Vilas;\r\nE muito mais;\r\n\r\nTambÃ©m esta no ar a promoÃ§Ã£o de crÃ©ditos em dobro, aproveite o comeÃ§o do round e adquira os seus crÃ©ditos e aproveite parar ganhar o dobro.', '2011-03-25 12:00:00', '2011-08-22 23:59:59'),
(30, 1, 'Promoção: Créditos em Dobro', 'Compre seus créditos vip e ganhe o dobro de créditos!', '2011-03-25 12:00:00', '2011-04-18 12:00:00'),
(31, 1, 'Promoção: Pascoa Ninja', 'Participe da Pascoa Ninja e encontre 16 ovos no mapa mundi e ganhe uma ótima recompensa.', '2011-04-24 00:00:00', '2011-04-24 23:59:00'),
(32, 1, 'Promoção: Créditos em Dobro', 'Compre seus créditos vip e ganhe o dobro de créditos!', '2011-05-09 12:00:00', '2011-05-16 23:59:59'),
(33, 1, 'Manutenção dos Servidores', 'A manutenção dos servidores acontece todas as terças feiras das 15:00 até as 15:30.', '2011-05-10 15:00:00', '2011-05-10 15:30:00'),
(34, 1, 'Manutenção dos Servidores', 'A manutenção dos servidores acontece todas as terças feiras das 15:00 até as 15:30.', '2011-05-17 15:00:00', '2011-05-17 15:30:00'),
(35, 1, 'Manutenção dos Servidores', 'A manutenção dos servidores acontece todas as terças feiras das 15:00 até as 15:30.', '2011-05-24 15:00:00', '2011-05-24 15:30:00'),
(36, 1, 'Manutenção dos Servidores', 'A manutenção dos servidores acontece todas as terças feiras das 15:00 até as 15:30.', '2011-05-31 15:00:00', '2011-05-31 15:30:00'),
(37, 2, 'Pre Oficial Round 2', 'Pre Oficial do Round 2 do Bleach Game, fase de testes, sem premiacao e o jogo sera resetado ao termino do Round Pre.', '2011-05-13 15:00:00', '2011-05-30 15:00:00'),
(38, 1, 'Evento: Karaoke Naruto Game', 'Como funcionará?\nCada pessoa poderá entrar com apenas uma conta no concurso, ou seja, um envio por pessoa. Os jogadores deverão fazer vídeos de si mesmos cantando alguma música do anime Naruto ou Naruto Shippuuden, com a mesma tocando de fundo (pode ser música versão karaokê ou normal, mas com a voz baixa).\n\nOs três melhores receberão prêmios, e serão avaliados pela Staff. O principal critério de avaliação será a pronuncia mais parecida com a original e com o tempo sincronizado.\n\nAs inscrições serão de 1º de Junho até 1º de Julho, e o resultado, dependendo da quantidade de inscrições, até 1º de Agosto.\n\nComo participar?\n1. O jogador terá que ter alguma forma de filmar (câmera, filmadora, celular, webcam).\n2. Caso não tenha nenhuma música, baixe de algum site. Site recomendado: http://www.mp3.animaniaclub.com.br/\n3. O nome do vídeo deverá conter \"Karaokê Naruto Game - seu nick\" e postado no Youtube: http://www.youtube.com/\n4. Deverá ser enviado para o email concurso@narutogame.com.br com as seguintes informações :\n\nAssunto : Concurso de Karaokê\nNome : -Seu nome-\nEmail da conta : -Seu email usado para jogar-\nLink do vídeo : -O link do seu vídeo-\n \nPremiação\n1º Lugar : VIP Jounin + Camiseta + Boneco\n2º Lugar : VIP Chuunin + Camiseta\n3º Lugar : VIP Genin + Camiseta\n\nBônus\nCaso cheguemos a 1000 inscrições, nós da Staff que faremos um vídeo cantando para vocês! Haha eu sei, coitado de vocês, mas será a chance de vocês nos conhecerem, assim como nós estaremos conhecendo vocês.\n', '2011-06-01 00:00:00', '2011-07-10 23:59:59'),
(39, 1, 'Promoção: Créditos em Dobro', 'Compre seus créditos vip e ganhe o dobro de créditos!', '2011-06-08 12:00:00', '2011-06-20 23:59:59'),
(40, 1, 'Promoção: Créditos em Dobro', 'Compre seus créditos vip e ganhe o dobro de créditos!', '2011-07-04 17:00:00', '2011-07-18 23:59:59'),
(41, 2, 'Round Oficial 2', 'Segundo Round Oficial do Bleach Game.', '2011-06-03 18:17:56', '2011-10-03 18:00:00'),
(42, 2, 'Fim do Round 2', 'Encerramento do Round Oficial 2 do Bleach Game', '2011-10-03 17:00:00', '2011-10-03 18:00:00'),
(43, 2, 'Manutenções e Fechamento', 'Manutenções, limpeza dos servidores, contabilização final dos Rankings.', '2011-10-04 00:00:00', '2011-10-05 00:00:00'),
(44, 1, 'Promoção: Créditos em Dobro', 'Compre seus créditos vip e ganhe o dobro de créditos!', '2011-08-01 17:00:00', '2011-08-15 23:59:59'),
(45, 1, 'Round Oficial 5', 'Inicio do Round Oficial do Naruto Game,\n\nPrezados jogadores é com grande alegria que anunciamos o inicio do Round 5 do Naruto Game.\n\nVenha particiapar de um dos melhores Rounds do melhor e mais completo WEBGame de Naruto da Internet.', '2011-09-27 15:00:00', '2012-02-27 15:00:00'),
(46, 1, 'Promoção: Créditos em Dobro', 'Compre seus créditos vip e ganhe o dobro de créditos!', '2011-10-01 15:00:00', '2011-11-01 20:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
CREATE TABLE IF NOT EXISTS `game` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`id`, `title`) VALUES
(1, 'Naruto Game'),
(2, 'Bleach Game'),
(3, 'Anime Game'),
(4, 'Pokemon Game');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(40) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `symbol` varchar(10) DEFAULT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `title`, `description`, `symbol`, `active`) VALUES
(1, 'PagSeguro', 'Doações nacionais', 'R$', '1'),
(2, 'PayPal Dolar', 'Doações internacionais', 'US$', '1'),
(3, 'PayPal Euro', 'Doações internacionais', 'EUR', '1');

-- --------------------------------------------------------

--
-- Table structure for table `payment_item`
--

DROP TABLE IF EXISTS `payment_item`;
CREATE TABLE IF NOT EXISTS `payment_item` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_payment` int(11) NOT NULL DEFAULT 0,
  `title` varchar(40) DEFAULT NULL,
  `value` float NOT NULL DEFAULT 0,
  `coin` smallint(6) NOT NULL DEFAULT 0,
  `active` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_id_payment` (`id_payment`),
  KEY `idx_active` (`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_item`
--

INSERT INTO `payment_item` (`id`, `id_payment`, `title`, `value`, `coin`, `active`) VALUES
(1, 1, 'VIP Plus', 10, 10, '1'),
(2, 1, 'VIP Shinigami Substituto', 20, 22, '1'),
(3, 1, 'VIP Tenente', 30, 35, '1'),
(4, 1, 'VIP Capitão', 40, 49, '1'),
(5, 1, 'VIP Comandante', 50, 64, '1'),
(6, 2, 'VIP Plus', 7, 10, '1'),
(7, 2, 'VIP Shinigami Substituto', 11, 22, '1'),
(8, 2, 'VIP Tenente', 15, 35, '1'),
(9, 2, 'VIP Capitão', 21, 49, '1'),
(10, 2, 'VIP Comandante', 24, 64, '1'),
(11, 3, 'VIP Plus', 6, 10, '1'),
(12, 3, 'VIP Shinigami Substituto', 10, 22, '1'),
(13, 3, 'VIP Tenente', 14, 35, '1'),
(14, 3, 'VIP Capitão', 18, 49, '1'),
(15, 3, 'VIP Comandante', 22, 64, '1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_country` tinyint(4) DEFAULT NULL,
  `id_game` tinyint(4) DEFAULT NULL,
  `id_ref` int(11) NOT NULL DEFAULT 0,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `key` varchar(44) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `newsletter` tinyint(1) DEFAULT 1,
  `sound` tinyint(1) DEFAULT 1,
  `msg_vip` tinyint(1) DEFAULT 1,
  `name` varchar(40) NOT NULL DEFAULT '',
  `date_ins` timestamp NOT NULL DEFAULT current_timestamp(),
  `removed` tinyint(1) NOT NULL DEFAULT 0,
  `ip` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sex` tinyint(1) NOT NULL DEFAULT 0,
  `street` varchar(80) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `neighborhood` varchar(72) DEFAULT NULL,
  `state` varchar(40) DEFAULT NULL,
  `zip` char(8) DEFAULT NULL,
  `vip` tinyint(1) NOT NULL DEFAULT 0,
  `ref` varchar(40) DEFAULT NULL,
  `last_activity` timestamp NULL DEFAULT NULL,
  `coin` int(11) NOT NULL DEFAULT 0,
  `pay_lock` tinyint(1) NOT NULL DEFAULT 0,
  `birthday` date DEFAULT NULL,
  `sid` varchar(33) DEFAULT NULL,
  `vip_char_slots` tinyint(4) NOT NULL DEFAULT 0,
  `has_fb` enum('0','1') NOT NULL DEFAULT '0',
  `fb_access_token` varchar(200) DEFAULT NULL,
  `lang` varchar(2) NOT NULL DEFAULT 'br',
  `layout` enum('r8','r10') CHARACTER SET latin1 NOT NULL DEFAULT 'r8',
  `fb_uid` bigint(20) NOT NULL DEFAULT 0,
  `last_login` timestamp NULL DEFAULT NULL,
  `removido` tinyint(1) DEFAULT 0,
  `senha_alterada` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`(50)),
  KEY `idx_date_ins` (`date_ins`),
  KEY `idx_id_indicado` (`id_ref`),
  KEY `id_ref` (`id_ref`),
  KEY `key` (`key`),
  KEY `last_login` (`last_login`),
  KEY `idx_facebook` (`fb_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `id_country`, `id_game`, `id_ref`, `email`, `password`, `key`, `active`, `newsletter`, `sound`, `msg_vip`, `name`, `date_ins`, `removed`, `ip`, `sex`, `street`, `city`, `neighborhood`, `state`, `zip`, `vip`, `ref`, `last_activity`, `coin`, `pay_lock`, `birthday`, `sid`, `vip_char_slots`, `has_fb`, `fb_access_token`, `lang`, `layout`, `fb_uid`, `last_login`, `removido`, `senha_alterada`) VALUES
(1, NULL, 1, 0, 'example@email.com', '*6BB4837EB74329105EE4568DDA7DC67ED2CA2AD9', '8455938a1db5c475a87d76edacb6284e', 1, 1, 1, 1, '', '2021-10-22 19:59:46', 0, 2130706433, 0, NULL, NULL, NULL, NULL, NULL, 0, '0', '2021-10-22 16:59:46', 0, 0, NULL, NULL, 0, '0', NULL, 'en', 'r10', 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_flags`
--

DROP TABLE IF EXISTS `user_flags`;
CREATE TABLE IF NOT EXISTS `user_flags` (
  `id_user` int(11) DEFAULT NULL,
  `flag` varchar(30) DEFAULT NULL,
  `value` varchar(20) DEFAULT NULL,
  `layout` varchar(50) DEFAULT '0',
  `data_ins` timestamp NULL DEFAULT current_timestamp(),
  KEY `id_user` (`id_user`),
  KEY `id_user_2` (`id_user`,`flag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_game_sid`
--

DROP TABLE IF EXISTS `user_game_sid`;
CREATE TABLE IF NOT EXISTS `user_game_sid` (
  `id_game` smallint(6) NOT NULL DEFAULT 0,
  `id_user` int(11) NOT NULL DEFAULT 0,
  `sid` char(36) DEFAULT NULL,
  PRIMARY KEY (`id_game`,`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_proxy`
--

DROP TABLE IF EXISTS `user_proxy`;
CREATE TABLE IF NOT EXISTS `user_proxy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT 0,
  `ip` varchar(255) DEFAULT NULL,
  `date_ins` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_ref_given`
--

DROP TABLE IF EXISTS `user_ref_given`;
CREATE TABLE IF NOT EXISTS `user_ref_given` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL DEFAULT 0,
  `vip` tinyint(1) NOT NULL DEFAULT 0,
  `ryou` tinyint(1) NOT NULL DEFAULT 0,
  `credits` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
